prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>20873491681539343017
,p_default_application_id=>49473
,p_default_id_offset=>0
,p_default_owner=>'RESEARCHPS'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(24154002014240505518)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'TextToSpeech'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(function(){',
'    if(''speechSynthesis'' in window){',
'        speechSynthesis.onvoiceschanged = function() {',
'            var $voicelist = $(''#voices'');',
'            ',
'            if($voicelist.find(''option'').length == 0){',
'                speechSynthesis.getVoices().forEach(function(voice, index){',
'                    var $option = $(''<option>'')',
'                    .val(index)',
'                    .html(voice.name + (voice.default ? '' (default)'': ''''));',
'                    ',
'                    $voicelist.append($option);',
'                });',
'                ',
'                $voicelist.material_select();',
'            }',
'        }',
'        ',
'        $(''#speak'').click(function(){',
'            var text = $(''#message'').val();',
'            var msg = new SpeechSynthesisUtterance();',
'            var voices = window.speechSynthesis.getVoices();',
'            ',
'            msg.voice= voices[$(''#voices'').val];',
'            msg.rate = $(''#rate'').val() / 10;',
'            msg.pitch = $(''#pitch'').val();',
'            msg.text = text;',
'            ',
'            msg.onend = function(e){',
'                console.log(''Finished in ''+event.elapsedTime+ '' seconds.'');',
'            };',
'            ',
'            speechSynthesis.speak(msg);',
'        })',
'        ',
'        $(''#modal1'').openModal();',
'    }',
'})'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'PRAJAKTA.SHIRKE@HARBINGERGROUP.COM'
,p_last_upd_yyyymmddhh24miss=>'20200207063020'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(24154015864174505569)
,p_plug_name=>'Text To Speech'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">',
'',
'<div class="container">',
'    <div class="row">',
'        <nav>',
'            <div class="nav-wrapper">',
'                <div class = "col s12">',
'                    <a href="#" class="brand-logo"> Text To Speech example</a>',
'                </div>    ',
'            </div>',
'        </nav>',
'    </div>',
'',
'    <form class = "col s8 offset-s2">',
'        <div class="row">',
'            <label>Choose voice</label>',
'            <select id="voices"></select>',
'        </div>',
'        <div class="row">',
'        <div class="col s6">',
'            <label>Rate</label>',
'            <p class="range-field">',
'                <input type="range" id="rate" min="1" max="100" value="10" />',
'            </p>',
'        </div>',
'   ',
'        <div class="col s6">',
'            <label> Pitch</label>',
'            <p class="range-field">',
'                <input type="range" id="pitch" min="0" max="2" value="1" />',
'            </p>',
'        </div>',
'        </div>',
'        <div class = "col s12">',
'            <p>',
'                N.B Rate and Pitch only work with native voice.',
'            </p>',
'        </div>',
'   ',
'        <div class="row">',
'            <div class="input-field col s12">',
'                <textarea id="message" class="materialize-textarea"></textarea>',
'                <label> Write message </label>',
'            </div>',
'        </div>',
'        <a href="#" id="speak" class="waves-effect waves-light btn">Speak</a>',
'    </form>',
'</div>',
'',
'<div id="modal1" class="modal">',
'    <h4>Speech Synthesis not supported.</h4>',
'    <p>Your browser does not support speech sunthesis.</p>',
'    <p>We recommend you use Google chrome.</p>',
'    <div class="action-bar">',
'        <a href="#" class="waves-effect waves-green btn-flat modal-action modal-close"> Close</a>',
'    </div>',
'</div>',
'',
'<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>',
'<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>'))
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
